package create;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class CreateMethod {
	   public void createM() {
		   try {
			   Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3305/dbcsfinal", "root", "root@123");
			   String create = "CREATE TABLE IF NOT EXISTS student_data ( reg int, rollno int(50) PRIMARY KEY, name varchar(50), fname varchar(50), mname varchar(50), course varchar(50), sem varchar(50), year varchar(50));";
			   Statement stmt = conn.createStatement();
			   stmt.executeUpdate(create);
		   }
		   catch(Exception e) {
			   e.printStackTrace();
		   }
	   }
}
