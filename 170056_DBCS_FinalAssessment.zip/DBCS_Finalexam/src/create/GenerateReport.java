package create;

public class GenerateReport {

}
