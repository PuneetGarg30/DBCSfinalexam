package create;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InsertData {

	public static void insert(String reg, String rollno, String name, String fname, String mname, String course, String year, String sem) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3305/dbcsfinal", "root",
					"root@123");
			con.setAutoCommit(false);
			PreparedStatement pstm = null;
			
				String sql = "INSERT INTO student_data (reg, rollno, name, fname, mname, course, sem, year) VALUES('" + reg + "','" + rollno + "','" + name
						+ "','" + fname + "','" + mname + "','" + course + "','" + sem + "','"
						+ year +"')";
				pstm = (PreparedStatement) con.prepareStatement(sql);
				pstm.execute();
			
			con.commit();
			pstm.close();
			con.close();
		
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		} catch (SQLException ex) {
			System.out.println(ex);
		}

	}
}